#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 Asssignment 2 (21T3) 

You can use this file to test your comp_cell_avg_temp().

This file containing three test cases which you can choose by
adjusting the variable test_index in Line 19. 

You can use this file to come out with additional tests. 
"""

# %% import 
import comp_cell_avg_temp as comp_avg
import numpy as np 

# %% Tests 
test_index = 0 # Can be 0, 1 or 2 

if test_index == 0:
    temp_array_trimmed = np.array(
      [[33.5, 35.3, 33.6, 33.6, 33.5, 33.9, 32.3, 33.2, 53.8, 54.6, 53.4, 54.2],
       [33.1, 34.2, 34.1, 34.3, 34.7, 31.3, 32.3, 33.4, 57.5, 55. , 53.5, 56.1],
       [35.3, 35.4, 35.6, 32.6, 33.2, 34.3, 32.8, 33.1, 54.7, 55.4, 54.6, 55.1],
       [34.2, 36.1, 33.5, 32.4, 32.1, 33.5, 34.5, 35. , 53.8, 56.9, 54.5, 54.7],
       [33.4, 33.8, 36.2, 33. , 35. , 34.2, 33.8, 33.8, 55.7, 55.2, 56. , 54.5],
       [34.3, 35.9, 34.4, 34.2, 53.5, 54.2, 55.7, 54. , 56.3, 54.4, 55.5, 53.8],
       [34.7, 35.4, 34.7, 33.1, 53.6, 54.5, 54.4, 55.5, 54.7, 55.4, 55.1, 55.6],
       [33.3, 34.3, 33.6, 33.1, 55.4, 55.7, 55.4, 55.4, 55.8, 55. , 55.3, 54.1],
       [33.7, 33.5, 37. , 34.9, 57.6, 54.2, 54.9, 54.6, 56. , 55.7, 55.1, 55.9],
       [34. , 35.1, 33.6, 34.5, 56.2, 55.3, 55.2, 54. , 54.1, 54.5, 54.4, 56. ]]
    )
    module_shape = (2,3)    
    cell_shape = (5,4)
    
    temp_cell_avg_expected = np.array(
      [[34.16 , 33.495, 54.96 ],
       [34.365, 54.965, 55.135]]
        )
elif test_index == 1: 
    temp_array_trimmed = np.array(
      [[34.5, 34.9, 33.3, 33.6, 55.6, 55. , 55.4, 55. , 33.9, 35.4, 34.3, 36.3],
       [33.3, 33.7, 33.7, 32.6, 54.2, 53.9, 56.5, 55.2, 33.8, 33.1, 33.3, 32.4],
       [55.7, 56.3, 53.8, 55.6, 33.1, 34.3, 31.9, 31.7, 33.7, 34.3, 34.3, 34.3],
       [55. , 52.7, 57.5, 55. , 34. , 35.6, 33.6, 34.7, 32.6, 35.8, 33.3, 35.2],
       [34.9, 34.7, 32.1, 34.2, 32.7, 33.9, 32.4, 35.1, 33.4, 34.3, 34. , 34.6],
       [33.7, 33.6, 34.1, 36.2, 34.3, 34.8, 33.3, 33.3, 34.8, 32.3, 33.5, 35.3],
       [33.9, 33.6, 35.3, 33.3, 56.1, 55.7, 55.9, 55.4, 33.4, 35.7, 33.9, 32.5],
       [35. , 33. , 35.4, 33.5, 54.1, 55.6, 53.6, 55.1, 34.9, 36.2, 34.4, 34.2],
       [33.7, 34.1, 34. , 34.1, 55. , 55.5, 53.6, 54.7, 35.2, 33.9, 32.3, 34.7],
       [33.1, 32.8, 33.8, 33.5, 52.3, 53.1, 55.5, 55.3, 32.4, 34.8, 32.7, 32. ]]
        )        
    module_shape = (5,3)
    cell_shape = (2,4)
    
    temp_cell_avg_expected = np.array(
          [[33.7   , 55.1   , 34.0625],
           [55.2   , 33.6125, 34.1875],
           [34.1875, 33.725 , 34.025 ],
           [34.125 , 55.1875, 34.4   ],
           [33.6375, 54.375 , 33.5   ]]
      )
elif test_index == 2: 
    temp_array_trimmed = np.array(
          [[34.1, 35.2, 33.8, 56.6, 56.1, 55.8],
           [34. , 33.6, 35.8, 55.8, 55.5, 54.6],
           [35. , 34.3, 33.6, 54.8, 53.7, 56.2],
           [33.2, 35.6, 33.5, 53.1, 54.9, 56.2],
           [32. , 34.7, 32.2, 55.4, 54.2, 55.6],
           [34.5, 35. , 34.4, 53.7, 55.4, 56.7]]
        )
    module_shape = (2,2)
    cell_shape = (3,3)
    temp_cell_avg_expected = np.array(
        [[34.37777778, 55.45555556],
         [33.9       , 55.02222222]]
      )


# %% Run the function and check the answers     
    
temp_cell_avg_your = comp_avg.comp_cell_avg_temp(temp_array_trimmed,module_shape,cell_shape)


print('Your function returns:\n',temp_cell_avg_your)
print('The expected answer is:\n',temp_cell_avg_expected)

# For comparison, we need a tolerance 
TOL = 1e-5

if not type(temp_cell_avg_your) is np.ndarray:
    print('Your output is NOT a numpy array')
elif temp_cell_avg_your.shape != temp_cell_avg_expected.shape:
    print('Your output numpy array does NOT have your right shape')
elif not temp_cell_avg_your.dtype in ['float64','float','float32']  :
     print('Your output numpy array is NOT of float dtype')
else:
    comparison_output = np.allclose(temp_cell_avg_your, temp_cell_avg_expected, atol = TOL)    
    
    if comparison_output:
        print('Your answer is within the specified tolerance')
    else:
        print('Your answer is NOT within the specified tolerance') 





    
        
