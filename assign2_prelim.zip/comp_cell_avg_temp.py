#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 21T3 Assignment 2 

Template file comp_cell_avg_temp()

@author: 
"""



def comp_cell_avg_temp(temp_array_trimmed,module_shape,cell_shape):
