#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 Asssignment 2 (21T3) 

You can use this file to test your indices_to_retain_in_one_axis().

This file containing four test cases which you can choose by
adjusting the variable test_index in Line 19. 

You can use this file to come out with additional tests. 
"""

# %% import 
import indices_to_retain_in_one_axis as retain
import numpy as np 

# %% Tests 
test_index = 0 # Can be 0, 1, 2 or 3 

if test_index == 0:
    num_pixels_per_cell_one_axis = 2
    num_cells_per_module_one_axis = 3
    inter_cell_sep = 1
    indices_to_retain_expected = np.array([0,1,3,4,6,7],dtype = int)
elif test_index == 1: 
    num_pixels_per_cell_one_axis = 4
    num_cells_per_module_one_axis = 4
    inter_cell_sep = 2
    indices_to_retain_expected = np.array([0,1,2,3,6,7,8,9,12,13,14,15,18,19,20,21],dtype = int) 
elif test_index == 2: 
    num_pixels_per_cell_one_axis = 5
    num_cells_per_module_one_axis = 3
    inter_cell_sep = 3
    indices_to_retain_expected = np.array([0,1,2,3,4,8,9,10,11,12,16,17,18,19,20],dtype = int)
elif test_index == 3: 
    num_pixels_per_cell_one_axis = 5
    num_cells_per_module_one_axis = 1
    inter_cell_sep = 3
    indices_to_retain_expected = np.array([0,1,2,3,4],dtype = int)
    

# %% Run the function and check the answers     
    
indices_to_retain_your = retain.indices_to_retain_in_one_axis(num_pixels_per_cell_one_axis,
                                                                    num_cells_per_module_one_axis,
                                                                    inter_cell_sep)

print('Your function returns:',indices_to_retain_your)
print('The expected answer is:',indices_to_retain_expected)

if type(indices_to_retain_your) == list:
    print('The spec requires that the function output is a 1-d numpy array, not a list')
elif not type(indices_to_retain_your) is np.ndarray:
    print('Your output is NOT a numpy array')
elif indices_to_retain_your.ndim != 1:
    print('Your output numpy array does not have dimensions 1')        
elif indices_to_retain_your.shape != indices_to_retain_expected.shape:
    print('Your output numpy array does NOT have your right shape')
    print('Your output has shape:',indices_to_retain_your.shape)
    print('The expected shape is:',indices_to_retain_expected.shape)
elif not indices_to_retain_your.dtype in ['int64','int','int32']:
     print('Your output numpy array is NOT of int dtype')
else:
    comparison_output = np.all(indices_to_retain_your == indices_to_retain_expected)    
    
    if comparison_output:
        print('Your answer is correct')
    else:
        print('Your answer is NOT correct') 







    
        


