#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 21T3 Assignment 2 

Template file for check_for_hot_cells()

@author: 
"""
 

def check_for_hot_cells(temp_cell_avg,threshold_hot):    
