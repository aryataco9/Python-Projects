#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 21T3 Assignment 2 

Template file extract_cell_pixels()

@author: 
"""


import indices_to_retain_in_one_axis as retain

def extract_cell_pixels(temp_array,module_shape,cell_shape,inter_cell_sep):
