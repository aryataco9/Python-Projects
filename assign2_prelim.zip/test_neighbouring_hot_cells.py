#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 Asssignment 2 (21T3) 

You can use this file to test your neighbouring_hot_cells().

This file containing five test cases which you can choose by
adjusting the variable test_index in Line 19. 

You can use this file to come out with additional tests. 
"""

# %% import 
import neighbouring_hot_cells as neighbouring
import numpy as np 

# %% Tests 
test_index = 0 # Can be 0, 1, 2, 3 or 4 

if test_index == 0:
    hot_cells_array = np.array([[False, False, False, False],
                                [False, False, False, False],
                                [False, False, False, False]])
    bool_neighbouring_hot_cells_expected = False
elif test_index == 1: 
    hot_cells_array = np.array([[False,  True,  True, False],
                                [False, False, False, False],
                                [False, False, False, False]])
    bool_neighbouring_hot_cells_expected = True    
elif test_index == 2: 
    hot_cells_array = np.array([[False,  True, False, False],
                                [False, False, False,  True],
                                [False, False, False, False]])
    bool_neighbouring_hot_cells_expected = False 
elif test_index == 3: 
    hot_cells_array = np.array([[False,  True, False],
                                [False, False, False],
                                [False, False,  True],
                                [False, False,  True]])
    bool_neighbouring_hot_cells_expected = True 
elif test_index == 4: 
    hot_cells_array = np.array([[False,  True, False],
                                [False, False, False],
                                [False, False, False], 
                                [ True, False,  True],
                                [ True, False, False]])
    bool_neighbouring_hot_cells_expected = True     

# %% Run the function and check the answers     
    
bool_neighbouring_hot_cells_your = neighbouring.neighbouring_hot_cells(hot_cells_array)

print('Your function returns:',bool_neighbouring_hot_cells_your)
print('The expected answer is:',bool_neighbouring_hot_cells_expected)

if type(bool_neighbouring_hot_cells_your) is np.bool_ or \
   type(bool_neighbouring_hot_cells_your) is bool:
    comparison_output = bool_neighbouring_hot_cells_your == bool_neighbouring_hot_cells_expected
    
    if comparison_output:
        print('Your answer is correct')
    else:
        print('Your answer is NOT correct')     
else:
    print('Your function output does not appear to have the right datatype')


