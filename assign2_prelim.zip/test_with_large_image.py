#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 Asssignment 2 (21T3) 

This file uses a large image to test the functions
    extract_cell_pixels
    comp_cell_avg_temp
    check_for_hot_cells
    
The temp_array being used has a shape of (691, 376)

This temp_array and the expected outputs are stored in the file
test_with_large_image_data.npz
    
"""

# %% Import numpy and matplotlib
import numpy as np
import matplotlib.pyplot as plt # for showing images

# %% Load test image and specify parameters 

module_shape = (11,6)
cell_shape = (61,61) # Should make it bigger later on 
inter_cell_sep = 2
threshold_hot = 50.0

# temp_array is stored in the file final_test_data.npz
test_data = np.load('test_with_large_image_data.npz', allow_pickle = True)
temp_array = test_data['temp_array']

# Plot temp_array
plt.figure()
plt.imshow(temp_array, cmap = 'gray', vmin = 30, vmax = 60)
plt.title('The given temp_array')
plt.show()

# %% Test extract_cell_pixels()

import extract_cell_pixels as extract
temp_array_trimmed_your = extract.extract_cell_pixels(temp_array,module_shape,cell_shape,inter_cell_sep)

# Compare with the expected output 
temp_array_trimmed_expected = test_data['temp_array_trimmed_expected']
TOL = 1e-5

comparison_temp_array_trimmed = np.allclose(temp_array_trimmed_your, temp_array_trimmed_expected, atol = TOL)    
    
if comparison_temp_array_trimmed:
    print('Your temp_array_trimmed is within the specified tolerance')
else:
    print('Your temp_array_trimmed is NOT within the specified tolerance') 

# Plot your trimmed image against the expected
fig, ax = plt.subplots(1,2)
ax[0].imshow(temp_array_trimmed_expected, cmap = 'gray', vmin = 30, vmax = 60)
ax[0].set_title('Your temp_array_trimmed')

ax[1].imshow(temp_array_trimmed_expected, cmap = 'gray', vmin = 30, vmax = 60)
ax[1].set_title('Expected temp_array_trimmed')

plt.show()

# %% Test comp_cell_avg_temp()

import comp_cell_avg_temp as comp_avg
temp_cell_avg_your = comp_avg.comp_cell_avg_temp(temp_array_trimmed_your,module_shape,cell_shape)

# For comparison, we need a tolerance 
TOL = 1e-5
temp_cell_avg_expected = test_data['temp_cell_avg_expected']
comparison_cell_avg = np.allclose(temp_cell_avg_your, temp_cell_avg_expected, atol = TOL)    

if comparison_cell_avg:
    print('Your temp_cell_avg is within the specified tolerance')
else:
    print('Your temp_cell_avg is NOT within the specified tolerance') 

# %% Test check_for_hot_cells

import check_for_hot_cells as check_hot
num_hot_cells_your, hot_cells_array_your = check_hot.check_for_hot_cells(temp_cell_avg_your,threshold_hot)

# For comparison, load the expected output
num_hot_cells_expected = test_data['num_hot_cells_expected']
hot_cells_array_expected = test_data['hot_cells_array_expected']

comparison_num_hot_cells = num_hot_cells_your == num_hot_cells_expected

if comparison_num_hot_cells:
    print('Your num_hot_cells is correct')
else:
    print('Your num_hot_cells is NOT correct')     

comparison_hot_cells_array = np.all(hot_cells_array_your == hot_cells_array_expected)    

if comparison_hot_cells_array:
    print('Your hot_cells_array is correct')
else:
    print('Your hot_cells_array is NOT correct') 

    
