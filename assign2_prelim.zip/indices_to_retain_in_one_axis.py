#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 21T3 Assignment 2 

Template file indices_to_retain_in_one_axis()

@author: 
"""



def indices_to_retain_in_one_axis(num_pixels_per_cell_one_axis,num_cells_per_module_one_axis,inter_cell_sep):
    
    
    
