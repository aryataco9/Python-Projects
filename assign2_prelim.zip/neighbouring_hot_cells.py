#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 21T3 Assignment 2 

Template file neighbouring_hot_cells()

@author: 
"""


def neighbouring_hot_cells(hot_cells_array):
