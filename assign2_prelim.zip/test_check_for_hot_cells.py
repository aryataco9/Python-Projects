#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 Asssignment 2 (21T3) 

You can use this file to test your check_for_hot_cells().

This file containing three test cases which you can choose by
adjusting the variable test_index in Line 19. 

You can use this file to come out with additional tests. 
"""

# %% import 
import check_for_hot_cells as check_hot
import numpy as np 

# %% Tests 
test_index = 0 # Can be 0, 1 or 2 

if test_index == 0:
    temp_cell_avg = np.array([[54.4, 55.9, 55.3], 
                              [33.5, 54.9, 53.8]])
    threshold_hot = 50.5 
    num_hot_cells_expected = 5
    hot_cells_array_expected = np.array([[ True, True, True], 
                                         [False, True, True]])
elif test_index == 1: 
    temp_cell_avg = np.array([[30.4, 30.9, 31.3, 31.4], 
                              [30.5, 30.3, 30.8, 30.2],
                              [30.1, 30.6, 30.7, 30.3]])
    threshold_hot = 50.5 
    num_hot_cells_expected = 0
    hot_cells_array_expected = np.array([[False, False, False, False],
                                         [False, False, False, False],
                                         [False, False, False, False]])
elif test_index == 2: 
    temp_cell_avg = np.array([[50.4, 50.5, 50.7, 51.3, 31.4], 
                              [30.5, 30.3, 30.8, 30.2, 30.5]])
    threshold_hot = 50.6 
    num_hot_cells_expected = 2
    hot_cells_array_expected = np.array([[False, False,  True,  True, False],
                                         [False, False, False, False, False]])


# %% Run the function and check the answers     
    
num_hot_cells_your, hot_cells_array_your = check_hot.check_for_hot_cells(temp_cell_avg,threshold_hot)

print('For the computation of the number of hot cells:')
print('\tYour function returns:',num_hot_cells_your)
print('\tThe expected answer is:',num_hot_cells_expected)

comparison_num_hot_cells = num_hot_cells_your == num_hot_cells_expected

if comparison_num_hot_cells:
    print('\tYour answer for the first output is correct')
else:
    print('\tYour answer for the first output is NOT correct')     

print('\n') # Print a blank line         
print('For the computation of hot_cells_array:')
print('Your function returns: \n',hot_cells_array_your)
print('The expected answer is: \n',hot_cells_array_expected)

# Before comparing hot_cells_array_your with the expected answer, we first 
# check whether it is a numpy array of the right shape and type

if not type(hot_cells_array_your) is np.ndarray:
    print('Your hot_cells_array is NOT a numpy array')
elif hot_cells_array_your.shape != hot_cells_array_expected.shape:
    print('Your hot_cells_array does NOT have your right shape')
elif hot_cells_array_your.dtype != 'bool'  :
    print('Your hot_cells_array is NOT of bool dtype')
else:
    comparison_hot_cells_array = np.all(hot_cells_array_your == hot_cells_array_expected)    
    
    if comparison_hot_cells_array:
        print('Your answer for the second output is correct')
    else:
        print('Your answer for the second output is NOT correct') 





    
        
